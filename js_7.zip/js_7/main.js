//
// RESTful API
//
/*

GET -> lấy
POST -> gửi
PUT -> cập nhật (id) (PATCH)
DELETE -> xóa (id)

*/

const api_url = 'https://648704a4beba6297278fac79.mockapi.io/';
const shopee_api = '';

const end_point = {
	student: 'student'
}
//
// cách 1: viết kiểu ES5 (nó là 1 câu hỏi trong vòng phỏng vấn)
//
/*

let data = {}

fetch(api_url + end_point.student, {
	method: 'POST',
	headers: {
		'Content-Type': 'text/application-json',
		apiKey: '',
		authorization: ''
	},
	body: JSON.stringify(data)
}) 


fetch(api_url + end_point.student, {
	method: 'GET'
})
.then(function(res) {
	return res.json()
})
.then(function(data) {
	console.log(data)
})
.catch(function(error) {
	console.log(error)
})
*/
//
// cách 2: viết kiểu ES6
//
// async - await (xử lý bất đồng bộ)
/*

các func await chỉ có thể chạy bên trong func async

lazy loading

*/

const loading = {
	spinner() {
		let div = document.createElement('div');
		div.classList.add('loader');
		div.innerHTML = `
		<span class="spinner-1"></span>
		`;
		
		return div;
	},
	list() {
		let div = document.createElement('div');
		div.classList.add('loader');
		div.innerHTML = `
		<div class="item">
			<span class="ava loading"></span>
			<div>
				<div class="loading content long mb-6"></div>
				<div class="loading content short mb-6"></div>
				<div class="loading content short"></div>
			</div>
		</div>
		<div class="item">
			<span class="ava loading"></span>
			<div>
				<div class="loading content long mb-6"></div>
				<div class="loading content short mb-6"></div>
				<div class="loading content short"></div>
			</div>
		</div>
		`;
		
		return div;
	}
}

async function remove_loader() {
	document.querySelectorAll('.loader').forEach(loader => {
		loader.remove();
	})
}

let get_student = {
	api_url: api_url,
	end_point: end_point.student,
	method: 'GET',
	async callback(params) {
		await remove_loader();
		await render_student(params);
	}
}

let remove_student = {
	api_url: api_url,
	end_point: '',
	method: 'DELETE',
	async callback(params) {
		await remove_loader();
		await fetch_data(get_student);
	}
}

async function render_student(params) {
	document.querySelector('.container').innerHTML = '';
	for(let student of params) {
		let {avatar, name, age, createdAt, id} = student;
		
		let div = document.createElement('div');
		div.classList.add('item');
		div.innerHTML = `
		<span class="ava" style="background-image: url(${avatar})"></span>
		<span>
			<span class="text-secondary d-block mb-6">Name</span>
			<b>${name}</b>
		</span>
		<span>
			<span class="text-secondary d-block mb-6">Age</span>
			<b>${age}</b>
		</span>
		<span>
			<span class="text-secondary d-block mb-6">Created at</span>
			<b>${createdAt}</b>
		</span>
		<div class="options">
			<button class="delete"><i class="fa-regular fa-trash-can"></i></button>
		</div>
		`;
		
		div.querySelector('.delete').addEventListener('click', async function() {
			let confirm_val = confirm('delete this student?');
			//
			// delete func
			//
			if (confirm_val == true) {
				document.body.appendChild(loading.spinner());
				await delete_student(id);
			}
		});
		
		document.querySelector('.container').appendChild(div);
	}
}

async function delete_student(id) {
	remove_student.end_point = end_point.student + '/' + id;
	await fetch_data(remove_student);
}

async function fetch_data(params) {
	if (!params) {
		alert('không tồn tại request');
		return false;
	}
	let {api_url, end_point, method, callback} = params;
	
	try {
		let res = await fetch(api_url + end_point, {
			method: method
		});

		let data = await res.json();
		await callback(data);
	}
	catch(error) {
		console.log(error)
	}
}
fetch_data(get_student);
document.querySelector('.container').appendChild(loading.list());